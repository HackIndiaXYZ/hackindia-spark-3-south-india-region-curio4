"""
app.py — MedIntel Flask Application
─────────────────────────────────────
Routes:
  GET  /                    → Landing page (login/register prompt)
  GET  /register            → Register page
  POST /register            → Handle registration
  GET  /login               → Login page
  POST /login               → Handle login
  GET  /logout              → Logout
  GET  /dashboard           → User dashboard (history)
  GET  /analyze-page        → Upload & analyze page (auth required)
  POST /analyze             → Full prescription analysis (JSON)
  POST /explain/<key>       → AI explanation for a single medicine (JSON)
  DELETE /history/<id>      → Delete a history entry
"""

import os
import uuid
import json
import hashlib
import sqlite3
from pathlib import Path
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, jsonify,
    send_from_directory, session, redirect, url_for, flash
)
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

# ── Load environment ────────────────────────────────────────────────────────
load_dotenv()

# ── Flask setup ─────────────────────────────────────────────────────────────
BASE_DIR   = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH    = BASE_DIR / "data" / "medintel.db"
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "bmp", "tiff", "webp", "heic"}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024   # 20 MB
app.secret_key = os.environ.get("SECRET_KEY", "medintel-dev-secret-change-me")

# ── Import analysis modules ─────────────────────────────────────────────────
from ocr.ocr_module                  import extract_text
from matcher.medicine_matcher        import match_medicines, MEDICINE_DB
from interaction.interaction_checker import (
    check_interactions, get_safety_alerts, get_interaction_summary
)
from nlp.explanation_engine          import explain_medicine_ai, batch_explain
from schedule.schedule_parser        import parse_schedule, build_daily_timeline
from voice.voice_generator           import generate_prescription_audio, cleanup_audio


# ════════════════════════════════════════════════════════
#  DATABASE  (SQLite — zero config, file-based)
# ════════════════════════════════════════════════════════

def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id            TEXT PRIMARY KEY,
                name          TEXT NOT NULL,
                email         TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at    TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS prescriptions (
                id            TEXT PRIMARY KEY,
                user_id       TEXT NOT NULL,
                title         TEXT NOT NULL,
                ocr_text      TEXT,
                result_json   TEXT NOT NULL,
                medicines     TEXT,
                med_count     INTEGER DEFAULT 0,
                interaction_count INTEGER DEFAULT 0,
                created_at    TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
        """)


init_db()


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


# ── Auth helpers ────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return decorated


def current_user():
    if "user_id" not in session:
        return None
    with get_db() as conn:
        row = conn.execute(
            "SELECT id, name, email FROM users WHERE id = ?",
            (session["user_id"],)
        ).fetchone()
    return dict(row) if row else None


# ── File helpers ─────────────────────────────────────────────────────────────
def allowed_file(filename: str) -> bool:
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _save_upload(file) -> str:
    ext      = secure_filename(file.filename).rsplit(".", 1)[-1].lower()
    uid      = uuid.uuid4().hex
    filename = f"{uid}.{ext}"
    path     = UPLOAD_DIR / filename
    file.save(path)
    return str(path)


# ════════════════════════════════════════════════════════
#  AUTH ROUTES
# ════════════════════════════════════════════════════════

@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        name     = request.form.get("name", "").strip()
        email    = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirm", "")

        error = None
        if not name:
            error = "Name is required."
        elif not email or "@" not in email:
            error = "A valid email is required."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            with get_db() as conn:
                existing = conn.execute(
                    "SELECT id FROM users WHERE email = ?", (email,)
                ).fetchone()
                if existing:
                    error = "An account with this email already exists."

        if error:
            return render_template("register.html", error=error,
                                   name=name, email=email)

        user_id = uuid.uuid4().hex
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (id, name, email, password_hash, created_at) VALUES (?,?,?,?,?)",
                (user_id, name, email, hash_password(password),
                 datetime.now().isoformat())
            )

        session["user_id"]   = user_id
        session["user_name"] = name
        return redirect(url_for("dashboard"))

    return render_template("register.html", error=None)


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email    = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        with get_db() as conn:
            user = conn.execute(
                "SELECT * FROM users WHERE email = ? AND password_hash = ?",
                (email, hash_password(password))
            ).fetchone()

        if not user:
            return render_template("login.html",
                                   error="Invalid email or password.")

        session["user_id"]   = user["id"]
        session["user_name"] = user["name"]
        next_url = request.args.get("next", url_for("dashboard"))
        return redirect(next_url)

    return render_template("login.html", error=None)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("landing"))


# ════════════════════════════════════════════════════════
#  MAIN PAGE ROUTES
# ════════════════════════════════════════════════════════

@app.route("/")
def landing():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("landing.html")


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    with get_db() as conn:
        rows = conn.execute(
            """SELECT id, title, medicines, med_count, interaction_count, created_at
               FROM prescriptions WHERE user_id = ?
               ORDER BY created_at DESC""",
            (session["user_id"],)
        ).fetchall()
    history = [dict(r) for r in rows]
    return render_template("dashboard.html", user=user, history=history)


@app.route("/analyze-page")
@login_required
def analyze_page():
    user = current_user()
    return render_template("index.html", user=user)


@app.route("/prescription/<pid>")
@login_required
def view_prescription(pid):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM prescriptions WHERE id = ? AND user_id = ?",
            (pid, session["user_id"])
        ).fetchone()
    if not row:
        return redirect(url_for("dashboard"))
    data = dict(row)
    data["result"] = json.loads(data["result_json"])
    user = current_user()
    return render_template("prescription_detail.html", data=data, user=user)


@app.route("/history/<pid>", methods=["DELETE"])
@login_required
def delete_history(pid):
    with get_db() as conn:
        conn.execute(
            "DELETE FROM prescriptions WHERE id = ? AND user_id = ?",
            (pid, session["user_id"])
        )
    return jsonify({"ok": True})


# ════════════════════════════════════════════════════════
#  ANALYSIS ROUTE
# ════════════════════════════════════════════════════════

@app.route("/analyze", methods=["POST"])
@login_required
def analyze():
    image_path = None
    ocr_result = {"text": "", "engine": "manual", "confidence": 1.0, "error": None}

    # ── 1. Get text ────────────────────────────────────────────────────────
    if "image" in request.files and request.files["image"].filename:
        f = request.files["image"]
        if not allowed_file(f.filename):
            return jsonify({"error": "Unsupported file type. Use JPG, PNG, or similar."}), 400
        try:
            image_path = _save_upload(f)
            ocr_result = extract_text(image_path)
        except Exception as e:
            return jsonify({"error": f"OCR failed: {e}"}), 500

    elif request.is_json and request.json.get("text"):
        ocr_result["text"] = request.json["text"]
    elif request.form.get("text"):
        ocr_result["text"] = request.form["text"]
    else:
        return jsonify({"error": "No image or text provided."}), 400

    raw_text = ocr_result["text"]
    if not raw_text.strip():
        return jsonify({"error": "Could not extract any text. Try a clearer image.",
                        "ocr": ocr_result}), 422

    # ── 2. Analysis pipeline ───────────────────────────────────────────────
    medicines     = match_medicines(raw_text)
    interactions  = check_interactions(medicines)
    safety_alerts = get_safety_alerts(medicines)
    int_summary   = get_interaction_summary(interactions)
    explanations  = batch_explain(medicines)
    schedules     = parse_schedule(raw_text, medicines)
    timeline      = build_daily_timeline(schedules)

    # ── 3. Voice — multilingual (optional) ─────────────────────────────────
    audio_urls = {}
    enable_voice = request.form.get("voice") == "true" or \
                   (request.is_json and request.json.get("voice"))
    if enable_voice:
        try:
            cleanup_audio()
            from voice.voice_generator import generate_multilingual_audio
            langs_raw = request.form.get("langs", "en")
            selected_langs = [l.strip() for l in langs_raw.split(",") if l.strip() in ("en","hi","ta")]
            if not selected_langs:
                selected_langs = ["en"]
            audio_urls = generate_multilingual_audio(
                medicines, explanations, interactions, schedules,
                languages=selected_langs
            )
        except Exception:
            pass

    # ── 4. Build response ──────────────────────────────────────────────────
    med_list = [
        {
            "key":          m["key"],
            "generic":      m["generic"],
            "brand":        m["brand"],
            "category":     m["category"],
            "color":        m["color"],
            "uses":         m["uses"],
            "dosage":       m["dosage"],
            "side_effects": m["side_effects"],
            "warnings":     m["warnings"],
            "explanation":  explanations.get(m["key"], ""),
        }
        for m in medicines
    ]

    response = {
        "ocr":          {"text": raw_text, "engine": ocr_result["engine"],
                         "confidence": ocr_result["confidence"]},
        "medicines":    med_list,
        "interactions": interactions,
        "safety_alerts":safety_alerts,
        "summary":      int_summary,
        "schedules":    schedules,
        "timeline":     timeline,
        "audio":        audio_urls,
    }

    # ── 5. Save to history ─────────────────────────────────────────────────
    title = request.form.get("title", "").strip()
    if not title:
        names = [m["generic"] for m in medicines[:3]]
        title = ", ".join(names) if names else "Prescription"
        if len(medicines) > 3:
            title += f" +{len(medicines)-3} more"

    pid = uuid.uuid4().hex
    with get_db() as conn:
        conn.execute(
            """INSERT INTO prescriptions
               (id, user_id, title, ocr_text, result_json, medicines,
                med_count, interaction_count, created_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (
                pid,
                session["user_id"],
                title,
                raw_text,
                json.dumps(response),
                ", ".join(m["generic"] for m in medicines),
                len(medicines),
                len(interactions),
                datetime.now().isoformat()
            )
        )

    response["prescription_id"] = pid

    # ── 6. Cleanup ─────────────────────────────────────────────────────────
    if image_path:
        try:
            os.remove(image_path)
        except OSError:
            pass

    return jsonify(response)


# ── Explain single medicine ──────────────────────────────────────────────────
@app.route("/explain/<drug_key>", methods=["POST"])
@login_required
def explain_single(drug_key: str):
    from matcher.medicine_matcher import get_medicine
    med = get_medicine(drug_key)
    if not med:
        return jsonify({"error": f"Medicine '{drug_key}' not found."}), 404
    return jsonify({"key": drug_key, "explanation": explain_medicine_ai(med)})


@app.route("/static/audio/<path:filename>")
def serve_audio(filename):
    return send_from_directory(BASE_DIR / "static" / "audio", filename)


# ── Error handlers ───────────────────────────────────────────────────────────
@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "File too large. Maximum size is 20 MB."}), 413

@app.errorhandler(404)
def not_found(_):
    return redirect(url_for("landing"))

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": f"Server error: {e}"}), 500


# ── Run ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port  = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "true").lower() == "true"
    print(f"\n🩺  MedIntel running → http://localhost:{port}\n")
    app.run(debug=debug, host="0.0.0.0", port=port)
