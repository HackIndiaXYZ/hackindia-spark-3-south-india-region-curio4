"""
voice/voice_generator.py
─────────────────────────
Multi-language TTS: English (en), Hindi (hi), Tamil (ta)
Uses gTTS (Google Text-to-Speech). Falls back to pyttsx3 for English.

Hindi/Tamil text is generated via  AI translation when an API key exists,
otherwise falls back to structured English summaries with language labels.
"""

import os
import uuid
from typing import Dict, List, Optional

_STATIC_DIR = os.path.join(os.path.dirname(__file__), "..", "static", "audio")
os.makedirs(_STATIC_DIR, exist_ok=True)

# ── Supported languages ────────────────────────────────────────────────────
LANGUAGES = {
    "en": {"name": "English",  "gtts_code": "en"},
    "hi": {"name": "Hindi",    "gtts_code": "hi"},
    "ta": {"name": "Tamil",    "gtts_code": "ta"},
}

# ── Pre-built phrase templates (fallback when no AI translation) ───────────
_HINDI_TEMPLATES = {
    "intro":        "आपके नुस्खे में {n} दवाइयाँ हैं।",
    "no_medicine":  "इस नुस्खे में कोई दवाई नहीं मिली।",
    "no_interact":  "कोई खतरनाक दवाई प्रतिक्रिया नहीं मिली।",
    "critical_warn":"चेतावनी: {n} गंभीर दवाई प्रतिक्रिया मिली।",
    "schedule_intro":"यह आपकी दैनिक दवाई अनुसूची है।",
    "take_times":   "{name} {dose} — दिन में {times} बार लें।",
}
_TAMIL_TEMPLATES = {
    "intro":        "உங்கள் மருந்துச்சீட்டில் {n} மருந்துகள் உள்ளன.",
    "no_medicine":  "இந்த மருந்துச்சீட்டில் மருந்துகள் கண்டறியப்படவில்லை.",
    "no_interact":  "ஆபத்தான மருந்து தொடர்புகள் எதுவும் கண்டறியப்படவில்லை.",
    "critical_warn":"எச்சரிக்கை: {n} தீவிர மருந்து தொடர்புகள் கண்டறியப்பட்டன.",
    "schedule_intro":"இது உங்கள் தினசரி மருந்து அட்டவணை.",
    "take_times":   "{name} {dose} — தினமும் {times} முறை எடுக்கவும்.",
}


# ── Claude AI translation ──────────────────────────────────────────────────
def _translate_with_claude(text: str, target_lang: str) -> Optional[str]:
    """Translate text to Hindi or Tamil using Claude API."""
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
        lang_name = "Hindi" if target_lang == "hi" else "Tamil"
        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=600,
            messages=[{
                "role": "user",
                "content": (
                    f"Translate the following medical text to {lang_name}. "
                    f"Keep medicine names in English. Keep numbers as-is. "
                    f"Return ONLY the translated text, no explanations.\n\n{text}"
                )
            }]
        )
        return msg.content[0].text.strip()
    except Exception:
        return None


# ── Text builders ──────────────────────────────────────────────────────────
def build_medicine_summary_text(medicines: List[Dict], explanations: Dict[str, str],
                                 lang: str = "en") -> str:
    if not medicines:
        if lang == "hi": return _HINDI_TEMPLATES["no_medicine"]
        if lang == "ta": return _TAMIL_TEMPLATES["no_medicine"]
        return "No medicines were detected in this prescription."

    if lang == "en":
        parts = [f"Your prescription contains {len(medicines)} medicine{'s' if len(medicines)>1 else ''}."]
        for med in medicines:
            expl = explanations.get(med["key"], "")
            parts.append(f"{med['generic']}. {expl}")
        return "  ".join(parts)

    # Hindi / Tamil: try AI translation of English text first
    en_text = build_medicine_summary_text(medicines, explanations, lang="en")
    translated = _translate_with_claude(en_text, lang)
    if translated:
        return translated

    # Fallback: structured template
    tmpl = _HINDI_TEMPLATES if lang == "hi" else _TAMIL_TEMPLATES
    parts = [tmpl["intro"].format(n=len(medicines))]
    for med in medicines:
        parts.append(f"{med['generic']}.")
    return "  ".join(parts)


def build_interaction_warning_text(alerts: List[Dict], lang: str = "en") -> str:
    if not alerts:
        if lang == "hi": return _HINDI_TEMPLATES["no_interact"]
        if lang == "ta": return _TAMIL_TEMPLATES["no_interact"]
        return "Good news — no dangerous drug interactions were found."

    if lang == "en":
        critical = [a for a in alerts if a["severity"] == "CRITICAL"]
        high     = [a for a in alerts if a["severity"] == "HIGH"]
        parts = []
        if critical:
            parts.append(f"Warning: {len(critical)} critical drug interaction{'s' if len(critical)>1 else ''} detected.")
            for a in critical:
                parts.append(f"{a['drug_a']} and {a['drug_b']} should not be taken together. {a['message']}")
        if high:
            parts.append(f"{len(high)} high-risk interaction{'s' if len(high)>1 else ''} also found. Please consult your doctor.")
        return "  ".join(parts)

    en_text = build_interaction_warning_text(alerts, lang="en")
    translated = _translate_with_claude(en_text, lang)
    if translated:
        return translated

    tmpl = _HINDI_TEMPLATES if lang == "hi" else _TAMIL_TEMPLATES
    critical_count = sum(1 for a in alerts if a["severity"] == "CRITICAL")
    if critical_count:
        return tmpl["critical_warn"].format(n=critical_count)
    return tmpl["no_interact"]


def build_schedule_text(schedules: List[Dict], lang: str = "en") -> str:
    if not schedules:
        if lang == "hi": return "दवाई अनुसूची उपलब्ध नहीं है।"
        if lang == "ta": return "மருந்து அட்டவணை கிடைக்கவில்லை."
        return "No schedule information could be extracted."

    if lang == "en":
        parts = ["Here is your daily medicine schedule."]
        for s in schedules:
            times = ", ".join(s["schedule"])
            dose  = s["dose"] or ""
            line  = f"{s['medicine']} {dose}".strip()
            line += f", take {s['times_per_day']} time{'s' if s['times_per_day']!=1 else ''} per day at {times}"
            if s.get("food"): line += f". {s['food']}"
            if s.get("duration"): line += f". Duration: {s['duration']}"
            line += "."
            parts.append(line)
        return "  ".join(parts)

    en_text = build_schedule_text(schedules, lang="en")
    translated = _translate_with_claude(en_text, lang)
    if translated:
        return translated

    tmpl = _HINDI_TEMPLATES if lang == "hi" else _TAMIL_TEMPLATES
    parts = [tmpl["schedule_intro"]]
    for s in schedules:
        parts.append(tmpl["take_times"].format(
            name=s["medicine"], dose=s.get("dose") or "", times=s.get("times_per_day", 1)
        ))
    return "  ".join(parts)


# ── Audio generation ───────────────────────────────────────────────────────
def _gtts_generate(text: str, filename: str, lang: str = "en") -> bool:
    try:
        from gtts import gTTS
        gtts_lang = LANGUAGES.get(lang, {}).get("gtts_code", "en")
        tts = gTTS(text=text, lang=gtts_lang, slow=False)
        tts.save(filename)
        return True
    except Exception:
        return False


def _pyttsx3_generate(text: str, filename: str) -> bool:
    """English-only offline fallback."""
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty("rate", 160)
        engine.setProperty("volume", 1.0)
        tmp = filename.replace(".mp3", ".wav")
        engine.save_to_file(text, tmp)
        engine.runAndWait()
        if os.path.exists(tmp):
            os.rename(tmp, filename)
        return os.path.exists(filename)
    except Exception:
        return False


def generate_audio(text: str, prefix: str = "med", lang: str = "en") -> Optional[str]:
    if not text.strip():
        return None
    uid      = uuid.uuid4().hex[:8]
    filename = os.path.join(_STATIC_DIR, f"{prefix}_{lang}_{uid}.mp3")

    if _gtts_generate(text, filename, lang):
        return f"/static/audio/{os.path.basename(filename)}"
    if lang == "en" and _pyttsx3_generate(text, filename):
        return f"/static/audio/{os.path.basename(filename)}"
    return None


def generate_multilingual_audio(
    medicines: List[Dict],
    explanations: Dict[str, str],
    alerts: List[Dict],
    schedules: List[Dict],
    languages: List[str] = None
) -> Dict:
    """
    Generate audio for all three sections across multiple languages.

    Returns:
    {
      "en": {"summary_url": "...", "interaction_url": "...", "schedule_url": "..."},
      "hi": { ... },
      "ta": { ... }
    }
    """
    if languages is None:
        languages = ["en", "hi", "ta"]

    result = {}
    for lang in languages:
        summary_text     = build_medicine_summary_text(medicines, explanations, lang)
        interaction_text = build_interaction_warning_text(alerts, lang)
        schedule_text    = build_schedule_text(schedules, lang)
        result[lang] = {
            "summary_url":     generate_audio(summary_text,     prefix="summary",     lang=lang),
            "interaction_url": generate_audio(interaction_text, prefix="interaction", lang=lang),
            "schedule_url":    generate_audio(schedule_text,    prefix="schedule",    lang=lang),
            "lang_name":       LANGUAGES[lang]["name"],
        }
    return result


# Keep old signature for backward compat
def generate_prescription_audio(medicines, explanations, alerts, schedules, lang="en"):
    summary_text     = build_medicine_summary_text(medicines, explanations, lang)
    interaction_text = build_interaction_warning_text(alerts, lang)
    schedule_text    = build_schedule_text(schedules, lang)
    return {
        "summary_url":     generate_audio(summary_text,     prefix="summary",     lang=lang),
        "interaction_url": generate_audio(interaction_text, prefix="interaction", lang=lang),
        "schedule_url":    generate_audio(schedule_text,    prefix="schedule",    lang=lang),
    }


def cleanup_audio(max_files: int = 100):
    files = [
        os.path.join(_STATIC_DIR, f)
        for f in os.listdir(_STATIC_DIR)
        if f.endswith(".mp3") or f.endswith(".wav")
    ]
    if len(files) > max_files:
        files.sort(key=os.path.getctime)
        for old in files[:len(files) - max_files]:
            try: os.remove(old)
            except OSError: pass
