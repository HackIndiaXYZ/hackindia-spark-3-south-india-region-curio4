# MedIntel — AI Prescription Explainer

A full-stack web app that reads prescription images,
identifies medicines, checks for dangerous interactions, and explains
everything in plain language with voice readout support.

---

## Architecture

```
MedIntel/
├── app.py                        ← Flask server (routes + orchestration)
├── requirements.txt
├── .env.example                  ← Copy to .env and fill API key
│
├── ocr/
│   └── ocr_module.py             ← EasyOCR + OpenCV image → text pipeline
│
├── nlp/
│   └── explanation_engine.py     ← AI plain-language explanations
│
├── matcher/
│   └── medicine_matcher.py       ← Fuzzy medicine detection (RapidFuzz)
│
├── interaction/
│   └── interaction_checker.py    ← Drug interaction + safety alerts
│
├── schedule/
│   └── schedule_parser.py        ← Parses dosage schedules from OCR text
│
├── voice/
│   └── voice_generator.py        ← gTTS / pyttsx3 audio generation
│
├── data/
│   ├── medicines.csv             ← 50+ drug database
│   └── interactions.csv          ← 30 known interaction pairs
│
├── templates/
│   └── index.html                ← Jinja2 main template
│
├── static/
│   ├── style.css
│   ├── script.js
│   └── audio/                    ← Generated MP3 voice files (auto-cleaned)
│
└── uploads/                      ← Temp image uploads (auto-deleted after OCR)
```

---

## Quick Start

### 1. Clone / unzip the project
```bash
cd MedIntel
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

> **Tesseract (optional fallback)**
> If you want the Tesseract fallback OCR:
> - macOS: `brew install tesseract`
> - Ubuntu: `sudo apt install tesseract-ocr`
> - Windows: download from https://github.com/UB-Mannheim/tesseract/wiki

### 4. Configure environment
```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

### 5. Run the server
```bash
python app.py
```

Open http://localhost:5000

---

## Features

| Feature | Module | Notes |
|---|---|---|
| Image OCR | `ocr/ocr_module.py` | EasyOCR primary, pytesseract fallback |
| OpenCV preprocessing | `ocr/ocr_module.py` | Grayscale, denoise, adaptive threshold, deskew |
| Medicine detection | `matcher/medicine_matcher.py` | Exact + RapidFuzz fuzzy matching |
| Drug database | `data/medicines.csv` | 50+ drugs across 12 categories |
| Interaction check | `interaction/interaction_checker.py` | 30 known interaction pairs, 3 severity levels |
| Safety alerts | `interaction/interaction_checker.py` | Pregnancy, liver, kidney groups |
| AI explanations | `nlp/explanation_engine.py` | Claude Sonnet via Anthropic API, offline fallback |
| Schedule parsing | `schedule/schedule_parser.py` | Extracts dose/frequency, builds daily timeline |
| Voice readout | `voice/voice_generator.py` | gTTS (online) or pyttsx3 (offline) |

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/` | Main web UI |
| `POST` | `/analyze` | Full analysis — accepts `image` (file) or `text` (JSON/form) |
| `POST` | `/explain/<key>` | AI explanation for a single medicine |
| `GET` | `/health` | JSON health check |

### `/analyze` request format

**Image upload:**
```
Content-Type: multipart/form-data
Fields: image (file), voice (optional, "true")
```

**Text input:**
```json
{ "text": "Metformin 500mg twice daily\nAspirin 75mg..." }
```

### `/analyze` response format
```json
{
  "ocr":          { "text": "...", "engine": "easyocr", "confidence": 0.94 },
  "medicines":    [ { "key": "metformin", "generic": "Metformin", ... } ],
  "interactions": [ { "drug_a": "Warfarin", "drug_b": "Aspirin", "severity": "CRITICAL", ... } ],
  "safety_alerts":{ "pregnancy": [...], "liver": [...], "kidney": [...] },
  "summary":      { "total": 2, "critical": 1, "high": 0, "safe": false },
  "schedules":    [ { "medicine": "Metformin", "dose": "500mg", "times_per_day": 2, ... } ],
  "timeline":     [ { "time": "8 AM", "medicines": [...] } ],
  "audio":        { "summary_url": "/static/audio/...", ... }
}
```

---

## Drug Database

The database (`data/medicines.csv`) contains 50+ medicines across:

- Antidiabetics (Metformin, Glipizide, Sitagliptin, Insulin)
- Cardiovascular (Amlodipine, Lisinopril, Losartan, Metoprolol, Warfarin, Digoxin, Furosemide, Amiodarone)
- Cholesterol (Atorvastatin, Rosuvastatin, Simvastatin)
- GI / Acid (Omeprazole, Pantoprazole, Ondansetron, Domperidone)
- Pain / Analgesics (Paracetamol, Ibuprofen, Tramadol, Diclofenac)
- Antibiotics (Amoxicillin, Azithromycin, Ciprofloxacin, Metronidazole, Doxycycline)
- Respiratory / Allergy (Cetirizine, Montelukast, Salbutamol, Prednisolone)
- Psychiatric (Sertraline, Fluoxetine, Alprazolam, Clonazepam, Gabapentin, Phenytoin)
- Thyroid / Endocrine (Levothyroxine, Hydrocortisone)
- Antigout (Allopurinol, Colchicine)
- Supplements (Folic Acid, Vitamin D, Calcium)
- Dermatology (Isotretinoin)

To add medicines, simply add rows to `data/medicines.csv`.

---

## Medical Disclaimer

This tool is for **educational and demonstration purposes only**.
It does not constitute medical advice. Always consult a licensed
pharmacist or physician before making any medication decisions.

---

## License

MIT — free to use and modify for hackathon / educational purposes.
